#!/bin/bash
# Installation script for Faenza icon themes
# Written by Tiheum (matthieu.james@gmail.com)

ROOT_UID=0
if [ "$UID" -ne "$ROOT_UID" ]
then
	echo "Icon themes will be installed in $HOME/.icons. To make them available for all users, run this script as root."
else
	echo "Icon themes will be installed in /usr/share/icons and are available for all users."
fi
read -p "Do you want to continue ? [Y]es, [N]o : " response
case $response in
	[Yy]* ) ;;
    [Nn]* ) exit 99;;
    * ) echo "Wrong value: installaton aborted."; exit 1;;
esac

tar xf Faenza.tar.gz
tar xf Faenza-Dark.tar.gz

echo
read -p "Which distributor logo do you want to use ? [D]ebian, [F]edora, [L]inux Mint, [O]pensuse, [M]andriva, [U]buntu : " distro
distro="${input:-$distro}"
case $distro in
	[Dd]* ) iconname="distributor-logo-debian";;
    [Ff]* ) iconname="distributor-logo-fedora";;
    [Ll]* ) iconname="distributor-logo-linux-mint";;
    [Oo]* ) iconname="distributor-logo-opensuse";;
    [Mm]* ) iconname="distributor-logo-mandriva";;
    [Uu]* ) iconname="distributor-logo-ubuntu";;
    * ) echo "Wrong value: installaton aborted."; exit 1;;
esac
cd ./Faenza/places/scalable/ && ln -sf ./$iconname.svg distributor-logo.svg && cd ../../..
cd ./Faenza/places/48/ && ln -sf ./$iconname.png distributor-logo.png && cd ../../..
cd ./Faenza/places/32/ && ln -sf ./$iconname.png distributor-logo.png && cd ../../..
cd ./Faenza/places/24/ && ln -sf ./$iconname.png distributor-logo.png && cd ../../..
cd ./Faenza/places/22/ && ln -sf ./$iconname.png distributor-logo.png && cd ../../..
cd ./Faenza/places/16/ && ln -sf ./$iconname.png distributor-logo.png && cd ../../..

if [ "$UID" -eq "$ROOT_UID" ]
then
	if [ -d /usr/share/icons/Faenza ]
	then
		echo
		read -p "A existing installation have been detected in /usr/share/icons. Remove it previously ? [Y]es, [N]o :" response
		case $response in
			[Yy]* ) rm -Rf /usr/share/icons/Faenza 2>/dev/null; rm -Rf /usr/share/icons/Faenza-Dark 2>/dev/null;;
		    * ) ;;
		esac
	fi
fi
if [ -d $HOME/.icons/Faenza ]
then
	echo
	read -p "A existing installation have been detected in $HOME/.icons. Remove it previously ? [Y]es, [N]o :" response
	case $response in
		[Yy]* ) rm -Rf $HOME/.icons/Faenza 2>/dev/null; rm -Rf $HOME/.icons/Faenza-Dark 2>/dev/null;;
	    * ) ;;
	esac
fi

echo
if [ "$UID" -eq "$ROOT_UID" ]
then
	cp -R ./Faenza/ /usr/share/icons/
	cp -R ./Faenza-Dark/ /usr/share/icons/
else
	cp -R ./Faenza/ $HOME/.icons/
	cp -R ./Faenza-Dark/ $HOME/.icons/
fi
echo "Installation complete. Enjoy !"
exit 0
